﻿import csv
import json
import os
import xml.etree.ElementTree as ET

import funciones


CARPETA_PROGRAMA = os.path.dirname(os.path.abspath(__file__))
CARPETA_ENTRADA = os.path.join(CARPETA_PROGRAMA, "entrada")
CARPETA_EXPORTACIONES = os.path.join(CARPETA_PROGRAMA, "sistema_uci")
SIGNOS_CSV = [
    "Frecuencia Cardiaca",
    "Presion Arterial Sistolica",
    "Presion Arterial Diastolica",
    "Saturacion Oxigeno"
]


def cargar_archivo_seleccionado():
    while True:
        archivos = funciones.obtener_archivos(CARPETA_ENTRADA)
        print("\nArchivos de entrada:")
        for indice, nombre in enumerate(archivos):
            letra = ""
            numero = indice
            while numero >= 0:
                letra = chr(numero % 26 + ord("A")) + letra
                numero = numero // 26 - 1
            print(f"{letra}: {nombre}")

        seleccion = input(
            "Seleccione una letra o escriba el nombre del archivo "
            "(Enter para volver al menu): "
        ).strip()
        if not seleccion:
            return

        indice = None
        for posicion, nombre in enumerate(archivos):
            letra = ""
            numero = posicion
            while numero >= 0:
                letra = chr(numero % 26 + ord("A")) + letra
                numero = numero // 26 - 1
            if seleccion.upper() == letra or seleccion.lower() == nombre.lower():
                indice = posicion
                break

        if indice is None or not 0 <= indice < len(archivos):
            print("Archivo no encontrado. Elija una letra o nombre de la lista.")
            continue

        ruta = os.path.join(CARPETA_ENTRADA, archivos[indice])
        try:
            datos = funciones.cargar_archivo(ruta)
        except (OSError, ValueError, ET.ParseError) as error:
            print(f"No se pudo leer el archivo: {error}")
            continue

        print(f"Archivo leido: {archivos[indice]}")
        print(datos)
        return


def exportar_datos(pacientes):
    carpeta_json = os.path.join(CARPETA_EXPORTACIONES, "exportaciones_json")
    carpeta_csv = os.path.join(CARPETA_EXPORTACIONES, "exportaciones_csv")
    os.makedirs(carpeta_json, exist_ok=True)
    os.makedirs(carpeta_csv, exist_ok=True)

    for id_paciente, datos in pacientes.items():
        nombre_archivo = id_paciente.replace("/", "_").replace("\\", "_")
        ruta_json = os.path.join(carpeta_json, f"{nombre_archivo}.json")
        with open(ruta_json, "w", encoding="utf-8") as archivo:
            json.dump(datos, archivo, ensure_ascii=False, indent=2)

    ruta_csv = os.path.join(carpeta_csv, "signos_vitales.csv")
    with open(ruta_csv, "w", encoding="utf-8", newline="") as archivo:
        escritor = csv.writer(archivo)
        escritor.writerow(["id_paciente"] + SIGNOS_CSV)
        for id_paciente, datos in pacientes.items():
            signos = datos["signos_vitales"]
            fila = [id_paciente]
            for nombre in SIGNOS_CSV:
                signo = signos.get(nombre, {})
                valor = signo.get("valor", "")
                unidad = signo.get("unidad", "")
                fila.append(f"{valor} {unidad}".strip())
            escritor.writerow(fila)

    print(f"JSON individuales guardados en: {carpeta_json}")
    print(f"CSV de signos vitales guardado en: {ruta_csv}")


print("=" * 60)
print("Bienvenido al sistema de gestion y unificacion de informacion")
print("=" * 60)

while True:
    opcion = input("""Ingrese:
    \n1  para gestionar informacion (cargar archivo)
    \n2  para fusionar archivos de informacion
    \n3  para ver historia clinica
    \n4  para salir del sistema
    \n Opcion: """).strip()

    if opcion == "4":
        print("Gracias por usar el sistema.")
        break
    elif opcion == "1":
        cargar_archivo_seleccionado()
    elif opcion == "2":
        try:
            pacientes = funciones.fusionar_archivos(CARPETA_ENTRADA)
            if not pacientes:
                print("No se encontraron registros para exportar.")
                continue
            exportar_datos(pacientes)
            print(f"Se procesaron {len(pacientes)} pacientes.")
        except (OSError, ValueError, ET.ParseError) as error:
            print(f"No se pudo completar la unificacion: {error}")
    elif opcion == "3":
           if 'pacientes' not in locals() or not pacientes:
               print("\n[!] No hay historias clínicas unificadas en memoria. Ejecute primero la opción 2.")
           else:
               print("\n" + "=" * 60)
               print("         HISTORIA CLÍNICA CONSOLIDADA (UCI)")
               print("=" * 60)
               for id_pac, datos in pacientes.items():
                   hl7 = datos.get("paciente_hl7", {})
                   diag = datos.get("diagnostico", {})
                   signos = datos.get("signos_vitales", {})
                   tele = datos.get("telemetria", [])
                   print(f"\n--- PACIENTE: {id_pac} ---")
                   print(f"Nombre    : {hl7.get('nombre', 'Sin registrar')}")
                   print(f"Ubicación : {hl7.get('ubicacion', 'Sin registrar')}")
                   print("\n[Diagnóstico]")
                   print(f"  • Categoría : {diag.get('Categoria', 'N/A')}")
                   print(f"  • Conclusión: {diag.get('Conclusión', 'N/A')}")
                   print(f"  • Médico    : {diag.get('Médico', 'N/A')}")
                   print(f"\n[Signos Vitales]")
                   if isinstance(signos, dict):
                       for nom_s, val_s in signos.items():
                           print(f"  • {nom_s}: {val_s.get('valor', '')} {val_s.get('unidad', '')}")
                   print(f"\n[Telemetría Registrada] ({len(tele)} eventos)")
                   for t in tele:
                       print(f"  • [{t.get('fecha_hora')}] {t.get('sensor')}: {t.get('valor')} ({t.get('estado')})")
               print("-" * 60)
