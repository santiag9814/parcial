import os
import xml.etree.ElementTree as ET

def obtener_archivos(carpeta):
   """
   Lista todos los archivos compatibles (.txt y .xml)
   dentro de la carpeta de entrada.
   """
   if not os.path.exists(carpeta):
       return []
   archivos = [f for f in os.listdir(carpeta) if f.lower().endswith(('.txt', '.xml'))]
   return sorted(archivos)

def leer_archivo_hl7(ruta_archivo):
   """Extrae de HL7: nombre, id y ubicacion."""
   datos = {"nombre": "No especificado", "id": "No especificado", "ubicacion": "No especificado"}
   with open(ruta_archivo, "r", encoding="utf-8", errors="ignore") as f:
       for linea in f:
           linea = linea.strip()
           if not linea:
               continue
           campos = linea.split("|")
           if campos[0] == "PID":
               if len(campos) > 3 and campos[3]:
                   datos["id"] = campos[3].strip()
               if len(campos) > 5 and campos[5]:
                   partes = [p for p in campos[5].split("^") if p]
                   datos["nombre"] = " ".join(partes).strip()
           elif campos[0] == "PV1":
               if len(campos) > 3 and campos[3]:
                   datos["ubicacion"] = campos[3].replace("^", " ").strip()
   return datos

def leer_signos_vitales_xml(ruta_archivo):
   """Extrae de SignosVitales.xml: nombre, valor y unidad."""
   signos = {}
   try:
       tree = ET.parse(ruta_archivo)
       root = tree.getroot()
       for elem in root.iter():
           if "}" in elem.tag:
               elem.tag = elem.tag.split("}", 1)[1]
       for nodo in root.iter("sign"):
           nom = nodo.attrib.get("name", "Desconocido").strip()
           val = nodo.attrib.get("value", "0").strip()
           uni = nodo.attrib.get("unit", "").strip()
           signos[nom] = {"valor": val, "unidad": uni}
   except Exception as e:
       print(f"Error procesando signos vitales: {e}")
   return signos

def leer_diagnostico_xml(ruta_archivo):
   """Extrae de Diagnóstico.xml: Categoria, Conclusión y Médico."""
   diag = {"Categoria": "No registrada", "Conclusión": "No registrada", "Médico": "No registrado"}
   try:
       tree = ET.parse(ruta_archivo)
       root = tree.getroot()
       for elem in root.iter():
           if "}" in elem.tag:
               elem.tag = elem.tag.split("}", 1)[1]
       elem_cat = root.find(".//category")
       elem_concl = root.find(".//conclusion")
       elem_med = root.find(".//physician") or root.find(".//medico")
       if elem_cat is not None and elem_cat.text:
           diag["Categoria"] = elem_cat.text.strip()
       if elem_concl is not None and elem_concl.text:
           diag["Conclusión"] = elem_concl.text.strip()
       if elem_med is not None and elem_med.text:
           diag["Médico"] = elem_med.text.strip()
   except Exception as e:
       print(f"Error procesando diagnóstico: {e}")
   return diag

def leer_telemetria_txt(ruta_archivo):
   """Extrae telemetría: fecha/hora, id, sensor, valor, estado."""
   telemetria = []
   with open(ruta_archivo, "r", encoding="utf-8", errors="ignore") as f:
       for linea in f:
           linea = linea.strip()
           if not linea:
               continue
           partes = linea.split("|")
           if len(partes) >= 5:
               telemetria.append({
                   "fecha_hora": partes[0].strip(),
                   "id_paciente": partes[1].strip(),
                   "sensor": partes[2].strip(),
                   "valor": partes[3].strip(),
                   "estado": partes[4].strip()
               })
   return telemetria

def cargar_archivo(ruta_archivo):
   """
   Función llamada en la opción 1 de tu compañero.
   Detecta qué tipo de archivo es y retorna la información extraída.
   """
   nom = os.path.basename(ruta_archivo).lower()
   if "hl7" in nom:
       return leer_archivo_hl7(ruta_archivo)
   elif "signos" in nom or "obs" in nom:
       return leer_signos_vitales_xml(ruta_archivo)
   elif "diag" in nom:
       return leer_diagnostico_xml(ruta_archivo)
   elif "telemetria" in nom or "log" in nom:
       return leer_telemetria_txt(ruta_archivo)
   else:
       # Intento de detección automática por extensión
       if nom.endswith(".xml"):
           try:
               tree = ET.parse(ruta_archivo)
               root = tree.getroot()
               if "DiagnosticReport" in root.tag:
                   return leer_diagnostico_xml(ruta_archivo)
               else:
                   return leer_signos_vitales_xml(ruta_archivo)
           except Exception:
               return {}
       else:
           return leer_archivo_hl7(ruta_archivo)

def fusionar_archivos(carpeta_entrada):
   """
   Función llamada en la opción 2 de tu compañero.
   Escanea la carpeta de entrada, unifica los 12 archivos según los
   3 pacientes (PAT-849203, PAT-105928, PAT-573019) y retorna
   el diccionario general estructurado.
   """
   archivos = obtener_archivos(carpeta_entrada)
   if not archivos:
       return {}
   pacientes = {}
   # Mapeo de índices de archivo a pacientes (1, 2, 3)
   mapa_pacientes = {
       "1": "PAT-849203",
       "2": "PAT-105928",
       "3": "PAT-573019"
   }
   # Inicializar estructura
   for pat_id in mapa_pacientes.values():
       pacientes[pat_id] = {
           "paciente_hl7": {},
           "signos_vitales": {},
           "diagnostico": {},
           "telemetria": []
       }
   for archivo in archivos:
       ruta = os.path.join(carpeta_entrada, archivo)
       nom = archivo.lower()
       # Determinar a qué paciente pertenece según el número en el nombre del archivo
       num_pac = None
       for digito in ["1", "2", "3"]:
           if digito in nom:
               num_pac = digito
               break
       if not num_pac:
           continue
       id_pac = mapa_pacientes[num_pac]
       if "hl7" in nom:
           pacientes[id_pac]["paciente_hl7"] = leer_archivo_hl7(ruta)
       elif "signos" in nom:
           pacientes[id_pac]["signos_vitales"] = leer_signos_vitales_xml(ruta)
       elif "diag" in nom:
           pacientes[id_pac]["diagnostico"] = leer_diagnostico_xml(ruta)
       elif "telemetria" in nom or "log" in nom:
           pacientes[id_pac]["telemetria"] = leer_telemetria_txt(ruta)
   return pacientes